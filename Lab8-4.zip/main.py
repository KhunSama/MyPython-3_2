from machine import Pin
from utime import sleep

print("Hello, ESP32!")

led = [15,18,22,23]

for i in range(4):
    led[i] = Pin(led[i], Pin.OUT)

def fd():
    for i in range(4):
        led[i].on()
        sleep(0.2)
        led[i].off()
        sleep(0.2)

def bk():
    for i in range(3, -1, -1):
        led[i].on()
        sleep(0.2)
        led[i].off()
        sleep(0.2)

def mo():
    led[1].on()
    led[2].on()
    sleep(0.2)
    led[1].off()
    led[2].off()
    sleep(0.2)

    led[0].on()
    led[3].on()
    sleep(0.2)
    led[0].off()
    led[3].off()
    sleep(0.2)

    led[2].off()
    led[3].off()
    sleep(0.2)
    led[2].off()
    led[3].off()
    sleep(0.2)

def mi():
    led[0].on()
    led[3].on()
    sleep(0.2)
    led[0].off()
    led[3].off()
    sleep(0.2)

    led[1].on()
    led[2].on()
    sleep(0.2)
    led[1].off()
    led[2].off()
    sleep(0.2)

    led[2].off()
    led[3].off()
    sleep(0.2)
    led[2].off()
    led[3].off()
    sleep(0.2)

while True:

    fd()
    bk()
    mo()
    mi()