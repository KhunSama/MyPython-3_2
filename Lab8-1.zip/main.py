from machine import Pin
from utime import sleep

print("Hello, ESP32!")

led1 = Pin(15, Pin.OUT)
led2 = Pin(18, Pin.OUT)

while True:
  led1.on()
  sleep(0.2)
  led1.off()
  sleep(0.2)
  led2.on()
  sleep(0.2)
  led2.off()
  sleep(0.2)