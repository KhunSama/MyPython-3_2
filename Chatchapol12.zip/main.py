from machine import Pin
from utime import sleep

led1 = Pin(23,Pin.OUT)
led2 = Pin(22,Pin.OUT)
print("Hello, ESP32!")

def blink():
    while True:
        led1.on()
        sleep(0.5)
        led1.off()
        sleep(0.5)

        led2.on()
        sleep(0.5)
        led2.off()
        sleep(0.5)

blink()