from machine import Pin
from utime import sleep

print("Hello, ESP32!")

led = [15,18,22,23]
for i in range(4):
    led[i] = Pin(led[i], Pin.OUT)

while True:
    for i in range(4):
        led[i].on()
        sleep(0.2)
        led[i].off()
        sleep(0.2)
