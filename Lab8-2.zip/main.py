from machine import Pin
from utime import sleep

print("Hello, ESP32!")

led1 = Pin(15, Pin.OUT)
led2 = Pin(18, Pin.OUT)
led3 = Pin(22, Pin.OUT)
led4 = Pin(23, Pin.OUT)

while True:
  led1.on()
  sleep(0.2)
  led1.off()
  sleep(0.2)
  led2.on()
  sleep(0.2)
  led2.off()
  sleep(0.2)
  led3.on()
  sleep(0.2)
  led3.off()
  sleep(0.2)
  led4.on()
  sleep(0.2)
  led4.off()
  sleep(0.2)